package com.simpleprogrammer.proteintracker;

public class InvalidGoalException extends Exception {

}
