
public interface GoodTestsCategory {

}
