import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)
@Suite.SuiteClasses({
	HelloJUnitTest.class, 
	TrackingServiceTests.class
})
public class ProteinTrackerSuite {

}
