package com.simpleprogrammer.proteintracker;

public interface Notifier {

	boolean send(String message);

}
