
public interface BadCategory {

}
